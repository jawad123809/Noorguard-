package com.noorguard.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.Executors

/** DNS-filter VPN starter. It replies NXDOMAIN to blocked DNS names and forwards other DNS queries upstream.
 * This is deliberately a starter implementation: HTTPS/DoH/DoT and non-DNS traffic require a more complete engine.
 */
class NoorVpnService : VpnService() {
    companion object { const val ACTION_START="START"; const val ACTION_STOP="STOP"; private const val CH="noorguard"; private const val MTU=1500 }
    private val pool = Executors.newSingleThreadExecutor(); private var tun: android.os.ParcelFileDescriptor? = null
    private val blocked = setOf("pornhub.com","xvideos.com","xnxx.com","redtube.com","youporn.com","xhamster.com")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (intent?.action==ACTION_STOP) stopSelf() else if (intent?.action==ACTION_START) startVpn(); return START_STICKY }
    private fun startVpn() { if (tun!=null) return; createChannel(); startForeground(1001, notification()); tun=Builder().setSession("NoorGuard").addAddress("10.10.0.2",32).addRoute("0.0.0.0",0).addDnsServer("10.10.0.1").setMtu(MTU).establish(); tun?.let { fd -> pool.execute { loop(fd.fileDescriptor) } } }
    private fun loop(fd: java.io.FileDescriptor) {
        FileInputStream(fd).use { input -> FileOutputStream(fd).use { output -> val buf=ByteArray(MTU); while(!Thread.currentThread().isInterrupted) { val n=input.read(buf); if(n>0) handlePacket(buf,n,output) } } }
    }
    private fun handlePacket(p: ByteArray,n:Int,out:FileOutputStream) {
        if(n<28) return; val version=(p[0].toInt() ushr 4); if(version!=4) return; val ihl=(p[0].toInt() and 15)*4; val proto=p[9].toInt() and 255; if(proto!=17 || n<ihl+8) return
        val srcPort=u16(p,ihl); val dstPort=u16(p,ihl+2); if(dstPort!=53) return
        val dns= p.copyOfRange(ihl+8,n); if(dns.size<12) return; val qname=parseQname(dns) ?: return
        val blockedNow=blocked.any{qname==it || qname.endsWith("."+it)}
        val response=if(blockedNow) dnsBlockedResponse(dns) else forwardDns(dns)
        val ip=buildUdpIpv4Response(p,ihl,srcPort,dstPort,response)
        out.write(ip)
    }
    private fun forwardDns(q:ByteArray):ByteArray { DatagramSocket().use { s -> protect(s); s.soTimeout=2000; val a=DatagramPacket(q,q.size,InetAddress.getByName("1.1.1.1"),53); s.send(a); val b=ByteArray(4096); val r=DatagramPacket(b,b.size); s.receive(r); return b.copyOf(r.length) } }
    private fun protect(s:DatagramSocket) { try { super.protect(s) } catch(_:Throwable){} }
    private fun parseQname(d:ByteArray):String? { var i=12; val labels=mutableListOf<String>(); while(i<d.size){ val len=d[i].toInt() and 255; i++; if(len==0) break; if(len>63 || i+len>d.size) return null; labels += String(d,i,len,Charsets.US_ASCII).lowercase(); i+=len }; return labels.joinToString(".").ifBlank{null} }
    private fun dnsBlockedResponse(q:ByteArray):ByteArray { val r=q.copyOf(); r[2]=(r[2].toInt() or 0x80).toByte(); r[3]=(r[3].toInt() and 0xF0 or 0x03).toByte(); return r }
    private fun buildUdpIpv4Response(req:ByteArray,ihl:Int,srcPort:Int,dstPort:Int,dns:ByteArray):ByteArray { val total=ihl+8+dns.size; val r=ByteArray(total); System.arraycopy(req,0,r,0,ihl); System.arraycopy(req,12,r,16,4); System.arraycopy(req,16,r,12,4); r[2]=(total ushr 8).toByte(); r[3]=total.toByte(); r[8]=64; r[9]=17; r[10]=0; r[11]=0; r[10]=checksum(r,0,ihl); r[11]=checksum(r,0,ihl).ushr(8).toByte(); r[ihl]=((dstPort ushr 8) and 255).toByte(); r[ihl+1]=dstPort.toByte(); r[ihl+2]=((srcPort ushr 8) and 255).toByte(); r[ihl+3]=srcPort.toByte(); val ul=8+dns.size; r[ihl+4]=(ul ushr 8).toByte(); r[ihl+5]=ul.toByte(); System.arraycopy(dns,0,r,ihl+8,dns.size); return r }
    private fun checksum(b:ByteArray,o:Int,l:Int):Byte { var sum=0L; var i=o; while(i<o+l-1){sum += ((b[i].toInt() and 255) shl 8) or (b[i+1].toInt() and 255); i+=2}; if((l and 1)==1) sum += (b[o+l-1].toInt() and 255) shl 8; while(sum ushr 16 !=0L) sum=(sum and 0xffff)+(sum ushr 16); return (sum.inv() and 0xff).toByte() }
    private fun u16(b:ByteArray,i:Int)=((b[i].toInt() and 255) shl 8) or (b[i+1].toInt() and 255)
    override fun onDestroy(){ pool.shutdownNow(); tun?.close(); tun=null; super.onDestroy() }
    private fun createChannel(){ if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CH,"NoorGuard",NotificationManager.IMPORTANCE_LOW)) }
    private fun notification():Notification=Notification.Builder(this,CH).setContentTitle("NoorGuard active").setContentText("Content protection is running").setSmallIcon(android.R.drawable.ic_lock_lock).build()
}
