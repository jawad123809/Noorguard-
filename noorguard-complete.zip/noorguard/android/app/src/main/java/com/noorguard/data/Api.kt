package com.noorguard.data

import com.noorguard.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.Interceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Header

data class AuthBody(val email:String,val password:String)
data class AuthResponse(val token:String,val user:UserDto)
data class UserDto(val id:String,val email:String,val role:String)
data class PurchaseBody(val productId:String,val purchaseToken:String)
data class SubscriptionStatus(val premium:Boolean,val subscription:Map<String,Any?>?)
data class DomainDto(val domain:String,val category:String)

interface NoorApi {
 @POST("auth/register") suspend fun register(@Body body:AuthBody):AuthResponse
 @POST("auth/login") suspend fun login(@Body body:AuthBody):AuthResponse
 @GET("payments/status") suspend fun paymentStatus():SubscriptionStatus
 @GET("blocklist") suspend fun blocklist():List<DomainDto>
 @POST("payments/google-play/verify") suspend fun verifyPlay(@Body body:PurchaseBody):Map<String,Any?>
}

object Session { @Volatile var token:String?=null }
private class AuthInterceptor:Interceptor { override fun intercept(chain:Interceptor.Chain):okhttp3.Response { val b=chain.request().newBuilder(); Session.token?.let{b.header("Authorization","Bearer $it")}; return chain.proceed(b.build()) } }
object ApiClient {
 val api:NoorApi by lazy { Retrofit.Builder().baseUrl(BuildConfig.BASE_URL).client(OkHttpClient.Builder().addInterceptor(AuthInterceptor()).build()).addConverterFactory(MoshiConverterFactory.create()).build().create(NoorApi::class.java) }
}
