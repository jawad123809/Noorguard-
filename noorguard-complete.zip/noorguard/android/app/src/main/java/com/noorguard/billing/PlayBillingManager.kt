package com.noorguard.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*
import com.noorguard.data.ApiClient
import com.noorguard.data.PurchaseBody
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PlayBillingManager(private val context:Context, private val scope:CoroutineScope) : PurchasesUpdatedListener {
    private val client = BillingClient.newBuilder(context).setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .enableAutoServiceReconnection().build()

    fun connect(onReady:()->Unit={}) { client.startConnection(object:BillingClientStateListener{
        override fun onBillingSetupFinished(r:BillingResult){ if(r.responseCode==BillingClient.BillingResponseCode.OK) onReady() }
        override fun onBillingServiceDisconnected() {}
    }) }

    fun buy(activity:Activity, productId:String) {
        val params=QueryProductDetailsParams.newBuilder().setProductList(listOf(QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(BillingClient.ProductType.SUBS).build())).build()
        client.queryProductDetailsAsync(params){ result,details ->
            if(result.responseCode!=BillingClient.BillingResponseCode.OK) return@queryProductDetailsAsync
            val pd=details.productDetailsList.firstOrNull() ?: return@queryProductDetailsAsync
            val offer=pd.subscriptionOfferDetails?.firstOrNull() ?: return@queryProductDetailsAsync
            val flow=BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).setOfferToken(offer.offerToken).build())).build()
            client.launchBillingFlow(activity,flow)
        }
    }

    override fun onPurchasesUpdated(result:BillingResult,purchases:MutableList<Purchase>?) {
        if(result.responseCode!=BillingClient.BillingResponseCode.OK || purchases==null) return
        purchases.filter{it.purchaseState==Purchase.PurchaseState.PURCHASED}.forEach { p ->
            scope.launch(Dispatchers.IO) {
                // Send the token to the backend. The backend verifies it with Google before granting premium.
                ApiClient.api.verifyPlay(PurchaseBody(p.products.firstOrNull() ?: "",p.purchaseToken))
            }
            if(!p.isAcknowledged) client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()){}
        }
    }
    fun close(){client.endConnection()}
}
