package com.noorguard

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.noorguard.data.ApiClient
import com.noorguard.data.AuthBody
import com.noorguard.data.Session
import com.noorguard.vpn.NoorVpnService
import com.noorguard.billing.PlayBillingManager
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {
 private lateinit var billing:PlayBillingManager
 private val vpnLauncher=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){if(it.resultCode==RESULT_OK)startProtection()}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);billing=PlayBillingManager(this, lifecycleScope);billing.connect();setContent{App()}}
 override fun onDestroy(){billing.close();super.onDestroy()}
 private fun startProtection(){startForegroundService(Intent(this,NoorVpnService::class.java).setAction(NoorVpnService.ACTION_START))}
 private fun requestVpn(){VpnService.prepare(this)?.let(vpnLauncher::launch)?:startProtection()}
 @Composable fun App(){val scope=rememberCoroutineScope();var email by remember{mutableStateOf("")};var password by remember{mutableStateOf("")};var logged by remember{mutableStateOf(false)};var protection by remember{mutableStateOf(false)};var message by remember{mutableStateOf("")};
  MaterialTheme{Surface(Modifier.fillMaxSize()){Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("NoorGuard",style=MaterialTheme.typography.headlineLarge);Text("Protect your eyes. Protect your heart.")
   if(!logged){Text("Create an account or sign in",style=MaterialTheme.typography.titleMedium);OutlinedTextField(email,{email=it},label={Text("Email")});OutlinedTextField(password,{password=it},label={Text("Password")});Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={scope.launch{try{val r=ApiClient.api.login(AuthBody(email,password));Session.token=r.token;logged=true;message="Signed in"}catch(e:Exception){message="Login failed"}}}){Text("Sign in")};Button(onClick={scope.launch{try{val r=ApiClient.api.register(AuthBody(email,password));Session.token=r.token;logged=true;message="Account created"}catch(e:Exception){message="Registration failed"}}}){Text("Register")}}}
   else {Text("Protection: ${if(protection)"ON" else "OFF"}");Button(onClick={if(!protection){requestVpn();protection=true}else{stopService(Intent(this@MainActivity,NoorVpnService::class.java));protection=false}}){Text(if(protection)"Stop protection" else "Start protection")};Text("Premium subscriptions are verified by the NoorGuard server.")
   Button(onClick={billing.buy(this@MainActivity,"noorguard_premium_monthly")}){Text("Subscribe — Premium") }};if(message.isNotBlank())Text(message)}}}}
}
