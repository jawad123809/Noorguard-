import jwt from 'jsonwebtoken'; import {Request,Response,NextFunction} from 'express';
export type AuthUser={sub:string,role:string};
export function requireAuth(req:Request,res:Response,next:NextFunction){const h=req.headers.authorization||'';const token=h.startsWith('Bearer ')?h.slice(7):'';if(!token)return res.status(401).json({error:'unauthorized'});try{(req as any).user=jwt.verify(token,process.env.JWT_SECRET!);next()}catch{res.status(401).json({error:'invalid_token'})}}
export function requireAdmin(req:Request,res:Response,next:NextFunction){requireAuth(req,res,()=>{if((req as any).user.role!=='ADMIN')return res.status(403).json({error:'admin_only'});next()})}
