import {google} from '@googleapis/androidpublisher';
export async function verifyGooglePlaySubscription(packageName:string,subscriptionId:string,purchaseToken:string){
 if(!process.env.GOOGLE_SERVICE_ACCOUNT_JSON) throw new Error('GOOGLE_SERVICE_ACCOUNT_JSON missing');
 const auth=new google.auth.GoogleAuth({credentials:JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_JSON),scopes:['https://www.googleapis.com/auth/androidpublisher']});
 const api=google.androidpublisher({version:'v3',auth});
 const r=await api.purchases.subscriptionsv2.get({packageName,token:purchaseToken});
 const s=r.data; const line=s.lineItems?.find(x=>x.productId===subscriptionId)||s.lineItems?.[0];
 const expiry=line?.expiryTime?new Date(line.expiryTime):undefined;
 const active=s.subscriptionState==='SUBSCRIPTION_STATE_ACTIVE'||s.subscriptionState==='SUBSCRIPTION_STATE_IN_GRACE_PERIOD'||s.subscriptionState==='SUBSCRIPTION_STATE_CANCELED';
 return {verified:active,expiresAt:expiry,state:s.subscriptionState,acknowledgementState:s.acknowledgementState,raw:s};
}
