export type EasyOrder={orderId:string,amountPkr:number,customerEmail:string,description:string};
/** Adapter only. Insert the exact merchant API flow supplied by Easypaisa for your merchant account.
 * Never place merchant keys, signing secrets, PINs or personal Easypaisa credentials in the Android app.
 */
export async function createEasypaisaOrder(o:EasyOrder){if(!process.env.EASYPAISA_BASE_URL||!process.env.EASYPAISA_MERCHANT_KEY)throw new Error('Easypaisa is not configured');
 const r=await fetch(`${process.env.EASYPAISA_BASE_URL}/checkout`,{method:'POST',headers:{'content-type':'application/json','x-merchant-key':process.env.EASYPAISA_MERCHANT_KEY},body:JSON.stringify({...o,callbackUrl:process.env.EASYPAISA_CALLBACK_URL})});
 if(!r.ok)throw new Error(`Easypaisa HTTP ${r.status}`); return r.json();}
export function verifyWebhookSignature(raw:string,signature:string){const crypto=awaitImportCrypto(); return crypto?true:false;}
function awaitImportCrypto(){return null as any;}
