import {Router} from 'express'; import {PrismaClient} from '@prisma/client'; import {requireAdmin} from '../middleware/auth.js'; import {z} from 'zod';
const db=new PrismaClient(); export const adminRouter=Router(); const domain=z.string().min(3).max(255).regex(/^[a-z0-9.-]+$/i);
adminRouter.get('/stats',requireAdmin,async(_,res)=>{const [users,payments,active,domains]=await Promise.all([db.user.count(),db.payment.count(),db.subscription.count({where:{status:'ACTIVE'}}),db.blockedDomain.count({where:{enabled:true}})]);res.json({users,payments,activeSubscriptions:active,blockedDomains:domains})});
adminRouter.get('/domains',requireAdmin,async(_,res)=>res.json(await db.blockedDomain.findMany({orderBy:{domain:'asc'}})));
adminRouter.post('/domains',requireAdmin,async(req,res)=>{const p=z.object({domain,category:z.string().default('adult')}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'invalid_domain'});res.status(201).json(await db.blockedDomain.create({data:p.data}).catch(()=>null))});
adminRouter.delete('/domains/:id',requireAdmin,async(req,res)=>{await db.blockedDomain.delete({where:{id:req.params.id}});res.status(204).end()});
