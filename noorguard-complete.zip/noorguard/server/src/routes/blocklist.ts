import {Router} from 'express'; import {PrismaClient} from '@prisma/client'; import {requireAuth} from '../middleware/auth.js';
const db=new PrismaClient(); export const blocklistRouter=Router();
blocklistRouter.get('/',requireAuth,async(_,res)=>res.json(await db.blockedDomain.findMany({where:{enabled:true},select:{domain:true,category:true},orderBy:{domain:'asc'}})));
