import 'dotenv/config'; import bcrypt from 'bcryptjs'; import {PrismaClient} from '@prisma/client';
const db=new PrismaClient();
const domains=['pornhub.com','xvideos.com','xnxx.com','xhamster.com','youporn.com','redtube.com','spankbang.com','porn.com','tube8.com','brazzers.com'];
async function main(){const email=process.env.ADMIN_EMAIL||'admin@example.com';const password=process.env.ADMIN_PASSWORD||'CHANGE_THIS_ADMIN_PASSWORD';await db.user.upsert({where:{email},update:{role:'ADMIN'},create:{email,passwordHash:await bcrypt.hash(password,12),role:'ADMIN'}});for(const domain of domains)await db.blockedDomain.upsert({where:{domain},update:{enabled:true},create:{domain,category:'adult'}});console.log(`Admin: ${email}`)}main().finally(()=>db.$disconnect());
