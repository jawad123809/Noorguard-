# NoorGuard — complete starter

NoorGuard is an Android content-filtering app with an API, PostgreSQL database, admin dashboard, Google Play subscription verification, and an Easypaisa merchant adapter.

## 1. What is included
- Android Kotlin/Jetpack Compose client
- Android `VpnService` DNS-filter starter
- Account registration/login with JWT
- Server-side subscription entitlement
- Google Play Billing purchase-token verification using Google Play Developer API
- Easypaisa server-side merchant adapter (provider-specific endpoint/signature must be filled from your approved merchant integration)
- PostgreSQL + Prisma
- Admin dashboard and blocklist API
- Seed script with admin account and starter domain list
- Docker Compose PostgreSQL

## 2. Security model
Never put JWT signing secrets, Google service-account credentials, Easypaisa merchant keys, signing secrets, or Easypaisa PINs in the APK. The Android app only receives a short-lived/rotatable access token and sends purchase tokens to the backend.

Google recommends secure backend verification and lifecycle handling for Play subscriptions. The backend should also process Real-time Developer Notifications (RTDN) and use `purchases.subscriptionsv2.get` as the current subscription-state source of truth.

## 3. Start PostgreSQL
From the repository root:

```bash
docker compose up -d postgres
```

Then configure `server/.env` from `.env.example`.

## 4. Start API

```bash
cd server
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run seed
npm run dev
```

Change `ADMIN_EMAIL` and `ADMIN_PASSWORD` before running the seed in a real deployment.

## 5. Start admin

```bash
cd admin
npm install
cp .env.example .env.local
npm run dev
```

The admin UI expects an admin JWT. For production, replace this simple dashboard with a proper admin login/session and CSRF protection.

## 6. Android
Open `android/` in Android Studio and allow Gradle to sync. Set the API URL in `app/build.gradle.kts`:

```kotlin
buildConfigField("String", "BASE_URL", "\"https://api.yourdomain.com/api/\"")
```

Create a Play Console subscription product matching the product ID used in the app. The backend must be linked to the Google Play Developer API using a service account with the required Play Console access.

The current Android client requests VPN consent through `VpnService.prepare()` and runs a foreground VPN service. Android's VPN API requires the service declaration/permission and user consent.

## 7. Google Play
Configure:
- `ANDROID_PACKAGE_NAME`
- `GOOGLE_SERVICE_ACCOUNT_JSON`
- Play Console subscription product/base plan
- Play Real-time Developer Notifications / Pub/Sub
- Backend endpoint for RTDN

Do not grant premium based only on an Android boolean. Verify the purchase token on the server, persist the entitlement, and update it when the subscription changes.

## 8. Easypaisa
The adapter in `server/src/services/easypaisa.ts` intentionally does not invent an endpoint, signature algorithm, or credential format. Easypaisa must provide the exact merchant/API integration for your account.

Set:
- `EASYPAISA_BASE_URL`
- `EASYPAISA_MERCHANT_KEY`
- `EASYPAISA_CALLBACK_URL`

Before activating the webhook, implement the exact signature verification and payment-status mapping specified by Easypaisa. Only after a verified successful callback should the server create/activate an Easypaisa subscription.

For a Google Play-distributed Android app, check Google's current billing/payment policies before adding any alternative digital-subscription payment flow inside the app.

## 9. Blocking limitations
The included VPN is a learning/starter implementation that handles IPv4 UDP DNS traffic. It is not a production-grade censorship engine. A production blocker should add:
- IPv6 handling
- DNS TCP fallback
- DoH/DoT policy handling
- packet forwarding for non-DNS traffic
- encrypted upstream DNS where appropriate
- continuously maintained blocklists
- fail-open/fail-closed policy chosen explicitly
- abuse/privacy logging controls
- per-app allow/disallow controls if needed
- robust reconnect and device reboot handling

Do not claim that this starter blocks every explicit site or every app.

## 10. Production checklist
- HTTPS everywhere
- secret manager instead of `.env` files on production hosts
- rate limiting and brute-force protection
- email verification and password reset
- refresh-token/session rotation
- secure admin authentication
- audit logs
- database backups
- privacy policy and data-retention policy
- Play VPN declaration/policy review
- subscription cancellation/refund handling
- Google RTDN processing
- Easypaisa webhook signature verification
- automated tests and Android device testing
